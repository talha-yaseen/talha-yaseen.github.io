			<div id="footer">
				<h3>&copy; BMIDC 2015 - All Rights Reserved</h3>
			</div>
		</div>
	</body>

	<script src="js/wow.min.js"></script>
	<script>
 		new WOW().init();
	</script>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="js/jquery.backstretch.min.js"></script>
	<script>
	    $("#intro").backstretch([
	      "img/slideshow/slide1.jpg",
	      "img/slideshow/slide2.jpg",
	      "img/slideshow/slide3.jpg",
	      "img/slideshow/slide4.jpg",
	      "img/slideshow/slide5.jpg",
	      "img/slideshow/slide6.jpg",
	      "img/slideshow/slide7.jpg",
	      "img/slideshow/slide8.jpg"
	      ], {
	        fade: 1500,
	        duration: 3500
	    });
	</script>

</html>