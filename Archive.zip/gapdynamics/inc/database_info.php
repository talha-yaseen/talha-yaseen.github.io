<?php
	//MySQL credentials
	$mysql_server = "localhost";
	$mysql_username = "root";
	$mysql_password = "";
	$mysql_db = "4848560526_gap_dynamics";
?>