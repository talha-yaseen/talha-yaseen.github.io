<div id="footer">
			Copyright &copy; LGS Graffiti 2017 - All Rights Reserved | Designed by Talha Yaseen
		</div>

	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
	<script src="js/selectnav.min.js"></script>
	<script>selectnav('nav-ul'); </script>
	</body>
</html>