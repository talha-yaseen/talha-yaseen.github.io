<div class="container black captureit">
	<h3>Team Cap</h3>
	<ul><li>A delegation may send one team only.</li><li>The team may consist of 1-2 people.</li></ul>
	<h3>Procedure</h3>
	<ul><li>It will consist of 3 rounds.</li><li>1st round about nature.</li><li>2nd round about Art.</li><li>3rd round about capturing candid pictures.</li></ul>
	<h3>Rules</h3>
	<ul><li>Fully manual photography</li><li>Good editing skills</li><li>Tripod not allowed</li></ul>
	<h3>Judging</h3>
	<ul><li>Based on vivid colours</li><li>Idea and story behind the picture</li></ul>
	<h3>Awards</h3>
	<ul><li>Best team: 6 points</li><li>Runners-up: 4 points</li></ul>
</div>