<div class="container black graffiti">
		<h3>Team Cap</h3>
		<p>Each each school may send one team comprising of 2-3 delegates, each delegate competing individually.</p>
		<h3>Topics</h3>
		<ul><li><b>Round one:</b> 'Every Child Matters' (Drawing must be done keeping the phrase in mind)</li><li><b>Rounds two and three:</b> Freely chosen by delegates</li></ul>
		<h3>PROCEDURE FOR ROUNDS 2 AND 3</h3>
		<ul><li>Topic chosen by delegates.</li><li>Mobile phones will be allowed.</li><li>Use of reference in form of printed paper is allowed.</li><li>Not allowed to bring drawings along.</li><li>Size of paper must be full A1 sheet or 1/2 A1 sheet.</li><li>Any medium is allowed.</li><li>Work started in 2nd round will be continued in the next round.</li></ul>
		<h3>RULES</h3>
		<ul><li>All drawings made in the allotted time will be made on campus and only during the designated time.</li><li>Participants are required to bring their own art material.</li><li>Management will not be responsible for any material brought by the delegates.</li><li>Obscene/Vulgar drawings will result in disqualification of delegate.</li><li>Showing up late or leaving before time is not allowed.</li></ul>
	</div>